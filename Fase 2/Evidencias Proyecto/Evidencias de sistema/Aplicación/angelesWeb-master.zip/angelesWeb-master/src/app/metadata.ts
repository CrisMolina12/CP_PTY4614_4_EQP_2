// src/app/metadata.ts
// src/app/metadata.ts

export const getMetadata = (pageTitle: string) => {
    return {
      title: pageTitle,
      description: "Angeles",
      // Otros metadatos que puedas necesitar
    };
  };
  
